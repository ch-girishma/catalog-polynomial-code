package catalogy;

public class SecretFinder {

	    // Class to represent a point
	    static class Point {
	        long x;
	        long y;

	        Point(long x, long y) {
	            this.x = x;
	            this.y = y;
	        }
	    }

	    // Function to calculate the power
	    static long power(long base, long exponent) {
	        long result = 1;
	        while (exponent > 0) {
	            result *= base;
	            exponent--;
	        }
	        return result;
	    }

	    // Function to convert a number from any base to decimal
	    static long convertToDecimal(String str, int base) {
	        long decimal = 0;
	        int length = str.length();
	        for (int i = 0; i < length; i++) {
	            char ch = str.charAt(i);
	            int value = 0;
	            if (ch >= '0' && ch <= '9') {
	                value = ch - '0';
	            } else if (ch >= 'a' && ch <= 'z') {
	                value = ch - 'a' + 10;
	            } else if (ch >= 'A' && ch <= 'Z') {
	                value = ch - 'A' + 10;
	            }
	            decimal += value * power(base, length - i - 1);
	        }
	        return decimal;
	    }

	    // Function to calculate the Lagrange basis polynomial
	    static long lagrangeBasis(Point[] points, int i, long x, int k) {
	        long numerator = 1;
	        long denominator = 1;
	        for (int j = 0; j < k; j++) {
	            if (i != j) {
	                numerator *= (x - points[j].x);
	                denominator *= (points[i].x - points[j].x);
	            }
	        }
	        return numerator / denominator;
	    }

	    // Function to calculate the secret using Lagrange interpolation
	    static long lagrangeInterpolation(Point[] points, int k) {
	        long secret = 0;
	        for (int i = 0; i < k; i++) {
	            secret += points[i].y * lagrangeBasis(points, i, 0, k);
	        }
	        return secret;
	    }

	    public static void main(String[] args) {
	        // Define the points for test case 1
	        Point[] points1 = {
	            new Point(1, convertToDecimal("4", 10)),
	            new Point(2, convertToDecimal("111", 2)),
	            new Point(3, convertToDecimal("12", 10)),
	            new Point(6, convertToDecimal("213", 4))
	        };

	        // Define the points for test case 2
	        Point[] points2 = {
	            new Point(1, convertToDecimal("13444211440455345511", 6)),
	            new Point(2, convertToDecimal("aed7015a346d63", 15)),
	            new Point(3, convertToDecimal("6aeeb69631c227c", 15)),
	            new Point(4, convertToDecimal("e1b5e05623d881f", 16)),
	            new Point(5, convertToDecimal("316034514573652620673", 8)),
	            new Point(6, convertToDecimal("2122212201122002221120200210011020220200", 3)),
	            new Point(7, convertToDecimal("20120221122211000100210021102001201112121", 3)),
	            new Point(8, convertToDecimal("20220554335330240002224253", 6)),
	            new Point(9, convertToDecimal("45153788322a1255483", 12)),
	            new Point(10, convertToDecimal("1101613130313526312514143", 7))
	        };

	        // Calculate secrets using only the first 3 and 7 points
	        long secret1 = lagrangeInterpolation(points1, 3);
	        long secret2 = lagrangeInterpolation(points2, 7);

	        // Print results
	        System.out.println("Secret for Test Case 1: " + secret1);
	        System.out.println("Secret for Test Case 2: " + secret2);
	    }
	}
